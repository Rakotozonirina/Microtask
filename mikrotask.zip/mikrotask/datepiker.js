document.addEventListener("DOMContentLoaded", function(){
    const startDateInput  = document.getElementById("startDate");
    const endDateInput = document.getElementById("endDate");
    const dateNowMonth = document.getElementById("date-now-month");
    const dateNowDay = document.getElementById("date-now-day");
    const renderDateMonth = document.getElementById("render-date-month");
    const renderDateDay = document.getElementById("render-date-day");
    const remainingDays = document.getElementById("remaining-days");
    const currentDate = new Date();
    const currentDateString = currentDate.toISOString().split('T')[0];
    startDateInput.value = currentDateString;
    function getMonthString(monthIndex){
        const monthNames = [
            "Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Aout", "Septembre", "Octobre", "Novembre", "Décembre"
        ];
        return monthNames[monthIndex];
    }

    startDateInput.addEventListener("change", function(){
        endDateInput.min = startDateInput.value;
        const selectedStartDate = new Date(startDateInput.value);
        dateNowDay.innerHTML = selectedStartDate.getDate();
        dateNowMonth.innerHTML = getMonthString(selectedStartDate.getMonth());
    });
    endDateInput.addEventListener("change", function(){
        startDateInput.max = endDateInput.value;
        const selectedEndDate = new Date(endDateInput.value);
        renderDateDay.innerHTML = selectedEndDate.getDate();
        renderDateMonth.innerHTML = getMonthString(selectedEndDate.getMonth());

        const timeDifference = selectedEndDate - currentDate;
        const remainingDaysValue = Math.ceil(timeDifference / (1000 * 60 * 60 * 24));
        remainingDays.innerHTML = remainingDaysValue > 0 ? remainingDaysValue + " jours restant" : "le date était passé";
    })
});